<footer class="container text-center">
    <hr style="border: 1px solid #393e41">
    <span>Developed and maintained by <strong>Nar Cuenca</strong>. All rights reserved &copy; 2017</span>
        <br>
    <span>
        <strong>Credits:</strong> <a href="https://github.com/dolce/iziModal" target="_blank" style="color: #1DB5AA">iziModal</a>: modal, <a href="http://kenwheeler.github.io/slick/" target="_blank" style="color: #1DB5AA">Slick</a>: carousel, <a href="http://ilikepixels.co.uk/bubbler-css-speech-bubble-generator/" target="_blank" style="color: #1DB5AA">ilikepixels</a>: chat bubbles, <a href="http://www.jqueryscript.net/other/Generating-Animated-Particles-with-jQuery-Canvas.html" target="_blank" style="color: #1DB5AA">jQueryscript.net</a>: particle effects & <a href="https://github.com/michalsnik/aos#-animations" target="_blank" style="color: #1DB5AA">michalsnik</a>: animate on scroll.
    </span>
</footer>