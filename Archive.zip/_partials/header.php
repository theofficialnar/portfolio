<header id="particles">
    <div class="h-cont text-center">
        <!-- <h1><span class="h-1">Fortis</span> <span class="h-2">Fortuna</span> <span class="h-3">Adiuvat</span></h1> -->
        <h1 class="header-title ">Welcome!</h1>
        <h4>Browse through my page to see what I can offer as a web developer.</h4>
    </div>
    <div class="scroll-cont">
        <a href="#mainBody" id="scrollArrow"><div class="arrow"></div></a>
    </div>
</header>