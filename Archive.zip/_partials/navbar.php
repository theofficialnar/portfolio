<ul class="nav nav-tabs nav-justified">
  <li class="active"><a data-toggle="tab" href="#home" data-toggle="tab">Home</a></li>
  <li><a data-toggle="tab" href="template.php#background" data-toggle="tab" id="bg-link">Background Profile</a></li>
  <li><a data-toggle="tab" href="#sample" data-toggle="tab">Portfolio</a></li>
  <li><a data-toggle="tab" href="#contact" data-toggle="tab">Contact</a></li>
</ul>
