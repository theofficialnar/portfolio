<div id="work" class="tab-pane fade">
	<h1 class="heading-no-margin">Work Page</h1>
	<p>Sample content</p>
</div>